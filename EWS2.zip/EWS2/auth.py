from flask import Blueprint, render_template, request, redirect, url_for
from flask.templating import render_template
#from EWS2 import utils
#from utils import preprocessdata 

auth = Blueprint('auth', __name__)



@auth.route('/logout')
def logout():
    return render_template("login.html")


#@auth.route('/home')
#def home():
#     if request.method == 'POST':
#         Sl_No= request.POST.get('slno')
#         Code= request.POST.get('code')
#         return render_template('predict.html', prediction="prediction")
#   return render_template("home.html")



# @auth.route('/predict/', methods=['GET', 'POST'])
# def predict():  
#     if request.method == 'POST': 
#         Sl_No= request.form.get('slno')
#         Code= request.form.get('code')
#         Company_Name= request.form.get('company')  
#         DOB= request.form.get('dob')
#         Age= request.form.get('age')
#         DOJ= request.form.get('doj')
#         BG= request.form.get('bg') 
#         Band= request.form.get('band') 
#         BU= request.form.get('bu') 
#         Department= request.form.get('department')
#         Sub_Department= request.form.get('subdepartment')
#         Business_Travel= request.form.get('businesstravel')
#         Location= request.form.get('location')
#         Education= request.form.get('education')
#         Exp_outside= request.form.get('exp_outside')
#         Exp_in_Vikarm= request.form.get('vs_exp')
#         Total_Experience= request.form.get('Gender')
#         Address= request.form.get('address')
#         Due_date_of_Confirmation= request.form.get('due')
#         Confirmation_Status= request.form.get('confirmation')
#         Payroll_Status= request.form.get('active')
#         Performance_Rating= request.form.get('rating')
#         Job_Satisfaction= request.form.get('satisfaction')
#         Work_Life_Balance= request.form.get('worklife')
#         Training_Time_Last_Year= request.form.get('training')
#         Gender = request.form.get('gender')

#     prediction = utils.preprocessdata(Sl_No, Code, Company_Name, Gender, DOB,
#        Age, DOJ, BG, Band, BU, Department,
#        Sub_Department, Business_Travel, Location,
#        Education, Exp_outside,
#        Exp_in_Vikarm, Total_Experience, Address,
#        Due_date_of_Confirmation, Confirmation_Status, Payroll_Status,
#        Performance_Rating, Job_Satisfaction, Work_Life_Balance,
#        Training_Time_Last_Year)

#     return render_template('predict.html', prediction=prediction) 

