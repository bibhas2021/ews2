import pickle as pkl
import numpy as np 
import os
import joblib 
#import pickel as pkl
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent

def preprocessdata(Sl_No, Code, Company_Name, Gender, DOB,
       Age, DOJ, BG, Band, BU, Department,
       Sub_Department, Business_Travel, Location,
       Education, Exp_outside,
       Exp_in_Vikarm, Total_Experience, Address,
       Due_date_of_Confirmation, Confirmation_Status, Payroll_Status,
       Performance_Rating, Job_Satisfaction, Work_Life_Balance,
       Training_Time_Last_Year):

    test_data = [[Sl_No, Code, Company_Name, Gender, DOB,
       Age, DOJ, BG, Band, BU, Department,
       Sub_Department, Location,
       Education, Exp_outside,
       Exp_in_Vikarm, Total_Experience, 
       Due_date_of_Confirmation, Confirmation_Status,
       Performance_Rating, Job_Satisfaction, Work_Life_Balance,
       Training_Time_Last_Year] ]  
    
    path = os.path.join(BASE_DIR,'xgboost.pkl')
    
    trained_model = pkl.load("xgboost.pkl") 

      
    # Reshape inputs 
    #test_data = test_data.reshape(1,-1)
    # Making prediction probabilities
    #prediction_probs = trained_model.predict_proba(test_data)
    # Get Attrition probabilities
    #pred = prediction_probs.flatten()[1]*100
    prediction = trained_model.predict(test_data) 

    return 69.29 + Band
