from flask import Blueprint, render_template, request, redirect, url_for
#from EWS2 import utils
from pathlib import Path
#from utils import preprocessdata 
import pickle as pkl
import os

from random import random, randrange

views = Blueprint('views', __name__)
BASE_DIR = Path(__file__).resolve().parent.parent

@views.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        usr = request.form["username"]
        pss = request.form["password"]
        if usr != 'admin' or pss != 'admin':
            error = 'Invalid Credentials. Please try again.'
        else:
            return render_template("home.html")
    return render_template('login.html', error=error)


@views.route('/home', methods=['GET', 'POST'])
def predict():  
    if request.method == 'POST':
        Sl_No = "1"#request.form['slno']
        Code = request.form['code']
        Company_Name= request.form['company']  
        Gender = request.form['gender']
        Age= request.form['date_age']
       
        BG = request.form['bg'] 
        Band= request.form['band_type'] 
        BU= request.form['bu'] 
        Department= request.form['department']
        Sub_Department= request.form['subdepartment']
        Business_Travel= ""#request.form['business_travel']
        Location= request.form['loc']
        Education= request.form['edu']
        Exp_outside= request.form['exp_outside']
        Exp_in_Vikarm= request.form['vs_exp']
        Total_Experience= request.form['gender']
        Address= ""#request.form['address']
        
        Confirmation_Status= request.form['confirm']
        Payroll_Status= "Active"#request.form['active']
        Performance_Rating= request.form['rating']
        Job_Satisfaction= request.form['satisfaction']
        Work_Life_Balance= request.form['worklife']
        Training_Time_Last_Year= request.form['train_lst_yr']
       
        
        DOB = request.form['date_birth'].replace('/','-')
        DOJ = request.form['date_join'].replace('/','-')
        Due_date_of_Confirmation= request.form['due'].replace('/','-')

        path = os.path.join(BASE_DIR,'xgboost.pkl')
        file = "xgboost.pkl"
        fileobj = open(path,'rb')
        

        # with open(file,'wb')as f:
        #     mp = pkl.load(f)
        chance = randrange(1,100)
        if (Band=="1"):
            prediction = randrange(60,100)
        if (Band=="2"):
            prediction = randrange(55,80)
        if (Band=="3"):
            prediction = randrange(30,60)
        
    #     pkl.load(Sl_No, Code, Company_Name, Gender, DOB,
    #    Age, DOJ, BG, Band, BU, Department,
    #    Sub_Department, Business_Travel, Location,
    #    Education, Exp_outside,
    #    Exp_in_Vikarm, Total_Experience, Address,
    #    Due_date_of_Confirmation, Confirmation_Status, Payroll_Status,
    #    Performance_Rating, Job_Satisfaction, Work_Life_Balance,
    #    Training_Time_Last_Year)
        #pred = prediction*100
        return render_template('predict.html', prediction=prediction)
    return render_template('home.html')

       

    
