
import pandas as pd
import os
from pathlib import Path

import collections
from collections import Counter

import pickle as pkl
import json

from django.http import JsonResponse

BD = Path("/").resolve()
BASE_DIR = Path("/content/").resolve().parent.parent
BASE_DIR1 = Path("/content/").resolve().parent

def checkingproba(request):
    if request.method == 'POST':
        path = os.path.join(BD,'logistic_regression.pkl')
        print(path)

        os.makedirs(os.path.dirname(path), exist_ok=True)
        model = pkl.load(open(path, 'rb'))

    