import pickle
import pandas as pd
import os
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent




def load(Sl_No, Code, Company_Name, Gender, DOB,
       Age, DOJ, BG, Band, BU, Department,
       Sub_Department, Business_Travel, Location,
       Education, Exp_outside,
       Exp_in_Vikarm, Total_Experience, Address,
       Due_date_of_Confirmation, Confirmation_Status, Payroll_Status,
       Performance_Rating, Job_Satisfaction, Work_Life_Balance,
       Training_Time_Last_Year):

       data = pd.DataFrame(list(zip(Gender, Company_Name, 
       Band, BG, BU,Confirmation_Status, Department, Sub_Department,
       Education, Location, Age, Exp_outside, Exp_in_Vikarm,Total_Experience, 
       Performance_Rating, Job_Satisfaction, Work_Life_Balance,
       Training_Time_Last_Year, DOB, DOJ, Due_date_of_Confirmation
        )),
        columns=['Gender', 'Company_Name', 'Band','BG', 'BU',
        'confirmation_status','Department','Sub_Department',
        'Higehest_Education_Qualification','Location','Age_As_On_date',
        'Exp_outside_Vikram','Exp_in_Vikarm','Total_Experience',
        'Performance_Rating', 'Job_Satisfaction', 'Work_Life_Balance',
       'Training_Time_Last_Year','Date_of_Birth','Date_of_Joining',
       'Due_date_of_Confirmation'])

       test_data = [[Sl_No, Code, Company_Name, Gender, DOB,
       Age, DOJ, BG, Band, BU, Department,
       Sub_Department, Location,
       Education, Exp_outside,
       Exp_in_Vikarm, Total_Experience, 
       Due_date_of_Confirmation, Confirmation_Status,
       Performance_Rating, Job_Satisfaction, Work_Life_Balance,
       Training_Time_Last_Year] ]  
    

path = os.path.join(BASE_DIR,'xgboost.pkl')
file = "xgboost.pkl"
fileobj = open(path,'rb')
mycar = pickle.load(fileobj)
print(mycar)
# print(type(mycar))

with open(file,'wb')as f:
    mp = pickle.load(f)

