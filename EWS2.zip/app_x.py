# from flask import Flask, views, render_template, redirect, sessions, url_for, request
# import pickle as pkl
# import os
# import pandas as pd
# from openpyxl import load_workbook




# filename = "EWS.xlsx"
# wb = load_workbook(filename)
# df = pd.read_excel(filename)
# df.head()
# app = Flask(__name__)
# usr = "Bibhas"
# objects = []
# with open('minmax_scaler.pkl', 'rb') as f:
#     x = pkl.load(f)

# pickle_file = open("xgboost.pkl", "rb")    
# fl_pkl = pkl.load(pickle_file)  
# pickle_file.close()

# path = os.path.join('logistic_regression.pkl')
# print(path)

# model = pkl.load(open(path, 'rb'))

# # Route for handling the login page logic



# @app.route('/', methods=['GET', 'POST'])
# def login():
#     error = None
#     if request.method == 'POST':
#         usr = request.form["username"]
#         pss = request.form["password"]
#         if usr != 'admin' or pss != 'admin':
#             error = 'Invalid Credentials. Please try again.'
#         else:
#             return redirect(url_for('home'))
#     return render_template('ews.html', error=error)


# @app.route('/logoff', methods=['GET', 'POST'])
# def logoff():
#     msg = "User Loggout"
#     error = None
#     if request.method == 'POST':
#         usr = request.form["username"]
#         pss = request.form["password"]
#         if usr != 'admin' or pss != 'admin':
#             msg = None
#             error = 'Invalid Credentials. Please try again.'
#         else:
#             return redirect(url_for('home'))
#     # return redirect(url_for('login'))
#     return render_template('ews.html', msg=msg, error=error)
    

# @app.route("/home", methods=['GET', 'POST'])
# def home():
   
#     #view the first five rows:     
#     return render_template("home.html", val_name = "Admin", Max = "66.25")


#@app.route("/file", method=['GET','POST'])

# def fl():
#      while True:
#         try:
#             objects.append(pkl.load(pickle_file))
#         except EOFError:
#             break     
#     pickle_file.close()
#     print(objects)



#if __name__ == "__main__":
#    app.run(debug=True, host='0.0.0.0')
#    app.run(debug=True)
